import React,{Component} from 'react'
import connect from './connect';
import { Tabs,Modal,Button,Tree, Icon } from 'antd';
import styled from 'styled-components';
import axios from 'axios';
import $ from 'jquery'
import {BrowserRouter as Router,Route,Link} from "react-router-dom";

const TabPane=Tabs.TabPane;
const DiretoryTree=Tree.DiretoryTree;
const TreeNode=Tree.TreeNode;
const Root=styled.div`
    width:40vw;
    height:50vh;
    margin:10vh auto 0 auto;
    border:1px solid lightBlue;

    ul{
        height:10%;
        padding:0;
        margin:0;
        list-style:none;
        border-bottom:1px solid lightblue;
        box-size:border-box;
        padding-left:100px;
        li{
            float:left;
            height:100%;
            font-size:14px;
            line-height:7vh;
            margin:0 10px;
            cursor:pointer;
        }
        
    }
    .ant-tabs{
        height:90%;
    }
`
const gData=[
    {title:"111",key:'0-0',children:[{title:"111--1",key:'0-0-0'},{title:"111--2",key:'0-0-1'}]},
    {title:"222",key:'0-1',children:[{title:"222--1",key:'0-1-0'},{title:"222--2",key:'0-1-1'}]}

]
@connect
export default class Demo1 extends React.Component{
    constructor(props){
        super(props);
        this.state={
            visible:false,
            gData
        }
        
    }
    componentWillMount(){
        this.props.init(this.props.dataAll[0]);
    }
    componentDidMount(){
        // console.log("/api/12")
        // axios.get("/1220562")
        //     .then((data)=>console.log("dataAA--:",data.data))
        //     .catch(()=>{
        //         alert('error')
        //     })
        $.ajax({
            url:"https://api.douban.com/v2/book/1220562",
            type:'get',
            dataType:'jsonp',
            jsonpCallback:'callback',
            success:function(data){
                console.log('-----------',data)
            }
        })
        window.addEventListener('hashchange',function(e){
            console.log(e)
        })
        
    }
    change=(val)=>{
        this.props.change(this.props.dataAll[val-1],this.props.data);
        this.props.checked(this.props.dataAll[val-1]);
       
    }
    click=(e)=>{
        this.props.checked(this.props.dataAll[e.target.id-1]);
    }
    drag(){
        this.setState({
            visible:true
        })
    }
    cancel(){
        this.setState({
            visible:false
        })
    }
    onDragEnter=(e)=>{
        console.log("dragEnter",e.node)
    }
    onDrop=(info)=>{
        const dropKey = info.node.props.eventKey;//移到的位置
        const dragKey = info.dragNode.props.eventKey;//被移动的
        const loop = (data, key, callback) => {
          data.forEach((item, index, arr) => {
            //每一项都遍历匹配一下，
            if (item.key === key) {
              return callback(item, index, arr);
            }
            if (item.children) {
              return loop(item.children, key, callback);
            }
          });
        };
        const data = [...this.state.gData];
        let dragObj;
        loop(data, dragKey, (item, index, arr) => {
            console.log(item,index,arr)
          arr.splice(index, 1);//每一项都遍历匹配一下，在数组中删除移动的项
          dragObj = item;
        });
        if (info.dropToGap) {
          let ar;
          let i;
          loop(data, dropKey, (item, index, arr) => {
            ar = arr;
            i = index;
          });
          ar.splice(i, 0, dragObj);//在数组中增加
        } else {
          loop(data, dropKey, (item) => {
            item.children = item.children || [];
            item.children.push(dragObj);
          });
        }
        this.setState({
          gData: data,
        });
    }
    render(){
        const act={
            color:'red',
            borderBottom:"1px solid blue"
        }
        const noact={
            color:"black",
            border:"none"
        }
        const loop = data => data.map((item) => {
            if (item.children) {
              return <TreeNode key={item.key} title={item.key}>{loop(item.children)}</TreeNode>;
            }
            return <TreeNode key={item.key} title={item.key} />;
          });
        return (
            <Root> 
                <ul>
                    {
                        this.props.data.map(item=>{
                           return React.cloneElement(
                                <li/>,
                                {key:item.id,id:item.id,onClick:this.click,style:((this.props.check===item)?act:noact)},
                                item.cont
                            )
                        })
                    }
                </ul>
                <Tabs tabPosition='left' size='large' onChange={this.change} activeKey={String(this.props.check.id)}>
                    {
                        this.props.dataAll.map((item)=>(
                            <TabPane tab={item.cont} key={item.id}>{item.cont}</TabPane>
                        ))
                    }
                </Tabs>
                <Button onClick={this.drag.bind(this)}>目录拖拽</Button>
                <a href='./admin.html' target='_blank' >open</a>
                <Modal title='拖拽' visible={this.state.visible} onOk={null} onCancel={this.cancel.bind(this)}>
                    {/* <Tree showIcon draggable defaultExpandAll onDragEnter={this.onDragEnter} onDrop={this.onDrop}>
                       
                            <TreeNode title='parent' key='0-0' icon={<Icon type="appstore" />}>
                                <TreeNode title='item1' key="0-0-0" isLeaf icon={<Icon type="file-text" />}/>
                                <TreeNode title='item2' key='0-0-1' isLeaf icon={<Icon type="file-text" />}/>
                            </TreeNode>
                            <TreeNode title='parent1' key='0-1' icon={<Icon type="appstore" />}>
                                <TreeNode title='item-1' key="0-1-0" isLeaf icon={<Icon type="file-text" />}/>
                                <TreeNode title='item-2' key='0-1-1' isLeaf icon={<Icon type="file-text" />}/>
                            </TreeNode>
                           
                     
                        
                    </Tree> */}
                    <Tree  draggable
                        onDragEnter={this.onDragEnter}
                        onDrop={this.onDrop}
                        defaultExpandAll>
                        {loop(this.state.gData)}
                    </Tree>
                </Modal>
            </Root>
        )
    }
}