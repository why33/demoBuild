import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import Action from './action';
import React,{Component} from 'react'

function mapStateToProps(state){
    return {...state}
}
function mapDispatchtoProps(dispatch){
    return bindActionCreators(Action,dispatch)
}

export default connect(mapStateToProps,mapDispatchtoProps)