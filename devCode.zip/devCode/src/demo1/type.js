export const type={
    change:'demo1/change',
    checked:'demo1/checked'
}