import React from 'react';
import ReactDOM from 'react-dom';
// import './index.css';

// import registerServiceWorker from './registerServiceWorker';
console.log(111)
ReactDOM.render(<h1>第二个页面</h1>, document.getElementById('root1'));